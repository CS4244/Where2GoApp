# Where2Go App in Flask

    *  Use only python 2
    *  pip install -r requirements.txt 
    * If an error occurs during pip install of pyclips follow the steps in https://www.youtube.com/watch?v=s7n0OwL2jE4
    * navigate to the directory where runserver.py is  and open command prompt before typing "python runserver.py" without the quotes
    * site should load in localhost:5000
    *  go to localhost:5000/expertapp
    *  look at the cmd prompt as you answer as the facts would be printed out


# Questions Not done, require further explanation
    *  visitmth
    *  region
    *  activitytype

# UI to be further improved
